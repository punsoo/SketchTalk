package messenger_project.catchmindtalk.adapter;

public class FriendListAdapter {
}
